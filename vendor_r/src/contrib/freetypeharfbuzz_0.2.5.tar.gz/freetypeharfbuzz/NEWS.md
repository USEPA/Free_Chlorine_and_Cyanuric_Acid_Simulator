
# freetypeharfbuzz 0.2.5

* Fix CRAN checks on Solaris


# freetypeharfbuzz 0.2.3


* Maintenance release for CRAN checks
* Export `font_info()`, `str_info()` and `str_width()`.


# freetypeharfbuzz 0.2.0

* Fixes to the build system
* Add static libraries for macOS


# freetypeharfbuzz 0.1.0

Initial release.
