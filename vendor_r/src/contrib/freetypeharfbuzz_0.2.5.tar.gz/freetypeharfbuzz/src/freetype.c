#include <stdlib.h> // for NULL

struct ft_library* library = NULL;
