library(testthat)
library(freetypeharfbuzz)

test_check("freetypeharfbuzz")
